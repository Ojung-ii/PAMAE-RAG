"""Graph and distance utilities."""
