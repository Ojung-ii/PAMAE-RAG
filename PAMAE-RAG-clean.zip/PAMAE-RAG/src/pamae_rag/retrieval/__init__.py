"""Context rendering utilities."""
